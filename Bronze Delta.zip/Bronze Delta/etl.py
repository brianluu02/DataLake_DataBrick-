# Databricks notebook source
# Databricks Notebook: silver_common_utils
from pyspark.sql.functions import *
from delta.tables import DeltaTable

CATALOG_NAME = "data_dev_olist"
SCHEMA_NAME = "silver"

# Tự động tạo Schema nếu chưa có
spark.sql(f"CREATE SCHEMA IF NOT EXISTS {CATALOG_NAME}.{SCHEMA_NAME}")

def run_silver_pipeline(
    source_folder_name: str,   
    table_name: str,           
    merge_key: str,            
    transform_func=None,       
    sync_delete=True           
):
    print(f"🚀 Khởi chạy pipeline cho: {source_folder_name} -> {table_name}")
    
    # 1. PATH CONFIGURATION
    source_path = f"abfss://raw-data@quocluudata.dfs.core.windows.net/bronze_delta/{source_folder_name}"
    silver_path = f"abfss://raw-data@quocluudata.dfs.core.windows.net/silver/{table_name}"
    target_table = f"{CATALOG_NAME}.{SCHEMA_NAME}.{table_name}"

    # 2. READ BRONZE
    df_bronze = spark.read.format("delta").load(source_path)

    # 3. TRANSFORM & DEDUPLICATE
    processed_df = df_bronze.na.drop()
    if transform_func:
        processed_df = transform_func(processed_df)
        
    processed_df = processed_df.dropDuplicates([merge_key])
    processed_df = (
        processed_df
        .withColumn("is_active", lit(True))
        .withColumn("_processed_at", current_timestamp())
    )

    # 4. KIỂM TRA THƯ MỤC VẬT LÝ TRÊN ADLS
    is_path_exists = False
    try:
        dbutils.fs.ls(silver_path)
        is_path_exists = True
    except:
        is_path_exists = False

    # 5. EXECUTE WRITE OR MERGE
    if not is_path_exists:
        print(f"  ✨ Thư mục vật lý chưa tồn tại hoặc rỗng. Tiến hành khởi tạo bảng: {target_table}...")
        (
            processed_df.write
            .format("delta")
            .mode("overwrite")
            .option("overwriteSchema", "true")
            .option("path", silver_path)
            .saveAsTable(target_table)
        )
    else:
        print(f"  🔄 Thư mục vật lý đã tồn tại. Tiến hành MERGE (Upsert) dựa trên khóa [{merge_key}]...")
        silver_table = DeltaTable.forName(spark, target_table)
        (
            silver_table.alias("target")
            .merge(
                processed_df.alias("source"),
                f"target.{merge_key} = source.{merge_key}"
            )
            .whenMatchedUpdateAll()
            .whenNotMatchedInsertAll()
            .execute()
        )

    # 6. FIX LỖI SYNC SOFT DELETE: CHUYỂN SANG DÙNG SƠ ĐỒ KẾT HỢP ĐỂ TƯƠNG THÍCH MỌI PHIÊN BẢN
    if sync_delete:
        print("  🗑 Đang đối chiếu kiểm tra dữ liệu bị xóa từ file nguồn Bronze...")
        active_source_ids = processed_df.select(merge_key)
        silver_table = DeltaTable.forName(spark, target_table)
        
        try:
            # Cách 1: Thử dùng hàm gốc tương thích phiên bản cũ hơn
            (
                silver_table.alias("target")
                .merge(
                    active_source_ids.alias("source"),
                    f"target.{merge_key} = source.{merge_key}"
                )
                .whenNotMatchedBySourceUpdate(
                    update={"is_active": lit(False), "_processed_at": current_timestamp()}
                )
                .execute()
            )
        except AttributeError:
            # Cách 2: Nếu cả hàm trên cluster cũng quá cũ, dùng SQL thuần chạy trực tiếp trên Delta Table
            print("  ⚠️ Cluster đang chạy phiên bản cũ. Chuyển hướng xử lý bằng Spark SQL...")
            
            # Tạo một View tạm thời chứa các ID đang hoạt động ở Bronze
            active_source_ids.createOrReplaceTempView("current_bronze_ids_view")
            
            spark.sql(f"""
                MERGE INTO {target_table} AS target
                USING current_bronze_ids_view AS source
                ON target.{merge_key} = source.{merge_key}
                WHEN NOT MATCHED BY SOURCE AND target.is_active = true THEN
                  UPDATE SET is_active = false, _processed_at = CURRENT_TIMESTAMP()
            """)

    # 7. PRINT SUMMARY METRICS
    final_df = spark.table(target_table)
    print(f"  📊 Tổng số dòng hiện tại ở Silver: {final_df.count()}")
    print(f"  🟢 Số dòng đang Active         : {final_df.filter('is_active = true').count()}")
    if sync_delete:
        print(f"  🔴 Số dòng đã bị Soft Deleted  : {final_df.filter('is_active = false').count()}")
    print(f"✅ Hoàn thành bảng: {table_name}\n" + "-"*50)

# COMMAND ----------

# MAGIC %run ./silver_common_utils

from pyspark.sql.functions import col, round, md5, concat, lit

# ==============================================================================
# 1. ĐỊNH NGHĨA LOGIC BIẾN ĐỔI ĐẶC THÙ CHO TỪNG BẢNG
# ==============================================================================
def transform_products(df):
    cols_to_int = ["product_description_length", "product_photos_qty", "product_length_cm", "product_height_cm", "product_width_cm"]
    for c in cols_to_int:
        if c in df.columns:
            df = df.withColumn(c, col(c).cast("integer"))
    if "product_weight_g" in df.columns:
        df = df.withColumn("product_weight_g", col("product_weight_g").cast("integer"))
    return df

def transform_order_items(df):
    # Tạo khóa tổ hợp duy nhất: pk_hash = md5(order_id + order_item_id)
    df = df.withColumn("pk_hash", md5(concat(col("order_id"), col("order_item_id"))))
    df = df.withColumn("price", round(col("price"), 2).cast("double")) \
             .withColumn("freight_value", round(col("freight_value"), 2).cast("double"))
    return df

def transform_payments(df):
    # Tạo khóa tổ hợp duy nhất: pk_hash = md5(order_id + payment_sequential)
    df = df.withColumn("pk_hash", md5(concat(col("order_id"), col("payment_sequential"))))
    df = df.withColumn("payment_value", round(col("payment_value"), 2).cast("double"))
    if "payment_installments" in df.columns:
        df = df.withColumn("payment_installments", col("payment_installments").cast("integer"))
    return df

def transform_reviews(df):
    if "review_comment_title" in df.columns:
        df = df.drop("review_comment_title")
    return df

def transform_geo(df):
    return df.filter(
        (col("geolocation_lat") <= 5.27438888)
        & (col("geolocation_lng") >= -73.98283055)
        & (col("geolocation_lat") >= -33.75116944)
        & (col("geolocation_lng") <= -34.79314722)
    )

# ==============================================================================
# 2. MẢNG CẤU HÌNH CHI TIẾT (Đã cập nhật đúng khóa chính duy nhất)
# ==============================================================================
tables_config = [
    {"source": "olist_customers", "target": "clean_customer", "key": "customer_id", "transform": None, "sync_delete": True},
    {"source": "olist_sellers", "target": "clean_seller", "key": "seller_id", "transform": None, "sync_delete": True},
    {"source": "olist_orders", "target": "clean_order", "key": "order_id", "transform": None, "sync_delete": True},
    {"source": "olist_products", "target": "clean_product", "key": "product_id", "transform": transform_products, "sync_delete": True},
    {"source": "olist_order_items", "target": "clean_order_item", "key": "pk_hash", "transform": transform_order_items, "sync_delete": True},
    {"source": "olist_order_payments", "target": "clean_payment", "key": "pk_hash", "transform": transform_payments, "sync_delete": True},
    {"source": "olist_order_reviews", "target": "clean_order_review", "key": "review_id", "transform": transform_reviews, "sync_delete": True},
    {"source": "olist_geolocation", "target": "clean_geolocation", "key": "geolocation_zip_code_prefix", "transform": transform_geo, "sync_delete": False},
    {"source": "product_category_name_translation", "target": "clean_product_category", "key": "product_category_name", "transform": None, "sync_delete": False}
]

# ==============================================================================
# 3. VÒNG LẶP TỰ ĐỘNG THỰC THI
# ==============================================================================
print(f"🔄 Đang quét danh sách thư mục trong 'bronze_delta' để xử lý...")
print("=" * 60)

for config in tables_config:
    try:
        run_silver_pipeline(
            source_folder_name=config["source"],
            table_name=config["target"],
            merge_key=config["key"],
            transform_func=config["transform"],
            sync_delete=config["sync_delete"]
        )
    except Exception as e:
        print(f"🔥 LỖI khi xử lý folder {config['source']}: {str(e)}")
        print("⏭️ Bỏ qua để chạy bảng tiếp theo...")
        print("=" * 60)

print("🏁 PIPELINE ĐÃ CHẠY HOÀN TẤT CHO CẢ TẬP DỮ LIỆU BRONZE DELTA!")

# ==============================================================================
# 4. XỬ LÝ ĐẶC THÙ CHO BẢNG DATE DIMENSION (DẪN XUẤT TỪ ORDERS)
# ==============================================================================
def transform_date_dimension(df):
    # Chỉ giữ lại cột timestamp, bỏ null và lấy giá trị duy nhất (distinct) giống code cũ
    return df.select("order_purchase_timestamp").na.drop().distinct()

try:
    print("📅 Bắt đầu khởi tạo/cập nhật bảng Date Dimension từ nguồn Orders...")
    
    run_silver_pipeline(
        source_folder_name="olist_orders",          # Đọc từ file nguồn Orders gốc
        table_name="date_dimension",                # Tên bảng đích ở tầng Silver
        merge_key="order_purchase_timestamp",       # Khóa chính để Merge
        transform_func=transform_date_dimension,    # Nạp logic lọc distinct timestamp
        sync_delete=False                           # Tắt Sync Delete vì đây là bảng Dim dẫn xuất
    )
    
except Exception as e:
    print(f"🔥 LỖI khi xử lý bảng Date Dimension: {str(e)}")

# COMMAND ----------

# MAGIC %sql
# MAGIC  table data_dev_olist.silver.clean_customer;

# COMMAND ----------

# MAGIC %sql 
# MAGIC select *from data_dev_olist.silver.clean_order_item

# COMMAND ----------

# MAGIC %sql
# MAGIC DESCRIBE EXTENDED data_dev_olist.silver.clean_order_item;
# MAGIC

# COMMAND ----------

display(
    dbutils.fs.ls(
        "abfss://raw-data@quocluudata.dfs.core.windows.net/silver/clean_customer"
    )
)

# COMMAND ----------

# MAGIC %sql 
# MAGIC DESCRIBE DETAIL data_dev_olist.silver.clean_customer;

# COMMAND ----------

# MAGIC %sql 
# MAGIC SHOW CREATE TABLE data_dev_olist.silver.clean_customer;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * 
# MAGIC FROM delta.`abfss://raw-data@quocluudata.dfs.core.windows.net/silver/clean_customer`
# MAGIC LIMIT 10;