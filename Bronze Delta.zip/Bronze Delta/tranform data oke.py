# Databricks notebook source
from pyspark.sql.functions import *

# =========================
# CONFIG
# =========================
catalog_name = "data_dev_olist"
schema_name = "silver"
table_name = "clean_customer"

source_path = (
    "abfss://raw-data@quocluudata.dfs.core.windows.net/"
    "bronze_delta/olist_customers"
)

silver_path = (
    "abfss://raw-data@quocluudata.dfs.core.windows.net/"
    "silver/clean_customer"
)

target_table = f"{catalog_name}.{schema_name}.{table_name}"

# =========================
# READ BRONZE
# =========================
df = (
    spark.read
    .format("delta")
    .load(source_path)
)

# =========================
# TRANSFORM
# =========================
processed_df = (
    df
    .na.drop()
    .dropDuplicates(["customer_id"])
    .withColumn("is_active", lit(True))
    .withColumn("_processed_at", current_timestamp())
)

# =========================
# WRITE DELTA TO ADLS
# =========================
(
    processed_df.write
    .format("delta")
    .mode("overwrite")
    .option("overwriteSchema", "true")
    .save(silver_path)
)

# =========================
# CREATE EXTERNAL TABLE
# =========================
spark.sql(f"""
CREATE SCHEMA IF NOT EXISTS {catalog_name}.{schema_name}
""")

spark.sql(f"""
CREATE TABLE IF NOT EXISTS {target_table}
USING DELTA
LOCATION '{silver_path}'
""")

print(f"Saved {processed_df.count()} rows")
print(f"External Table : {target_table}")
print(f"Location       : {silver_path}")

# COMMAND ----------

# MAGIC %sql
# MAGIC  table data_dev_olist.silver.clean_customer;

# COMMAND ----------

# MAGIC %sql
# MAGIC DESCRIBE EXTENDED data_dev_olist.silver.clean_customer;
# MAGIC

# COMMAND ----------

display(
    dbutils.fs.ls(
        "abfss://raw-data@quocluudata.dfs.core.windows.net/silver/clean_customer"
    )
)

# COMMAND ----------

# MAGIC %sql 
# MAGIC DESCRIBE DETAIL data_dev_olist.silver.clean_customer;

# COMMAND ----------

# MAGIC %sql 
# MAGIC SHOW CREATE TABLE data_dev_olist.silver.clean_customer;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * 
# MAGIC FROM delta.`abfss://raw-data@quocluudata.dfs.core.windows.net/silver/clean_customer`
# MAGIC LIMIT 10;